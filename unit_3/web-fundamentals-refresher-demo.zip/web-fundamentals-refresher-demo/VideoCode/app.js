// let n = 10;

// if (n > 0) {
//   console.log('n is valid')
// } else if (n < 100) {
//   console.log('n is valid')
// } else {
//   console.log('n is not valid')
// }
// let n = 10;

// if (n > 0) {
//   console.log('n is valid')
// }

// if (n < 100) {
//   console.log('n is valid')
// } else {
//   console.log('n is not valid')
// }

// for (let i = 0; i < 10; i++) {
//   console.log(i)
// }


// let msg = 'I hate mayo!';

// function greet() {
//   let msg = 'hiiiii';
//   console.log(msg)
// }

// console.log(msg);

// const person = { name: 'timothy', age: 58, talk: greet }


// function printReceipt(product, qty, price) {
//   return `${product}($${price}) * ${qty} = $${qty * price}`
// }


let colors = ['red', 'teal', 'cyan', 'yellow']

// for (let i = 0; i < colors.length; i++) {
//   console.log(colors[i])
// }

// for (let color of colors) {
//   console.log(color)
// }

// for (let char of "PURPLE RAIN!") {
//   console.log(char)
// }

const chicken = {
  name: "Lady Gray",
  age: 4,
  color: "Black"
}

// for (let prop in chicken) {
//   console.log(`${prop}->${chicken[prop]}`)
// }
for (let key in colors) {
  console.log(key)
}

